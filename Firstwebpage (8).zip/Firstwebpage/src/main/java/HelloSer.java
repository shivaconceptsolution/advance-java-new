

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloSer
 */
@WebServlet("/HelloSer")
public class HelloSer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloSer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int a=100,b=200,c;
		c=a+b;
		out.println("Result is "+c);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String s = request.getParameter("area");
		 float area;
		 int a = Integer.parseInt(request.getParameter("txtnum1"));
		 int b = Integer.parseInt(request.getParameter("txtnum2"));
		 if(s.equals("rectangle"))
		  {
			 area = a*b; 
		  }
		 else
		 {
			 area = (a*b)/2;
		 }
		 out.print("Area is "+area);
	}

}
