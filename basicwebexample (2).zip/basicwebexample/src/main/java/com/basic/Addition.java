package com.basic;

public class Addition {
    public int displayAddition(int a, int b)
     {
    	 return a+b;
     }
}
