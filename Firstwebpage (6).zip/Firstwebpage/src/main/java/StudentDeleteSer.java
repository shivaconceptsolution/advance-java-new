

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentDeleteSer
 */
@WebServlet("/StudentDeleteSer")
public class StudentDeleteSer extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
	    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ierp","root","");
	    Statement st = conn.createStatement();
	    int x = st.executeUpdate("delete from student where rno='"+request.getParameter("rno")+"'");
	    if(x!=0)
	    {
	    	response.sendRedirect("viewstudentrecordtable.jsp");
	    }
		}
		catch(Exception ex)
		{
			out.print(ex.getMessage().toString());
		}
	}

}
